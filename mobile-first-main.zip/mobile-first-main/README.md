# mobile-first
Curo mobile-first alura.
